# Read this before publishing the dataset

**The dataset contains verbatim third-party text.** Every segment carries the policy's own words,
and every claim cites a quote from them. That is deliberate — the evidence rule is what makes the
annotations checkable — but it means the release redistributes copyrighted material from 101
companies, none of whom have granted a licence.

This is not a reason not to publish. It is a reason to decide *how*, before rather than after.

## What is actually in here

| | |
|---|---|
| verbatim policy text | **yes** — full segment text, ~5.9 million characters |
| verbatim quotes | **yes** — 55,350 evidence spans |
| source URLs | yes |
| personal data about any individual | **no** — these are corporate policy documents |
| anything about the annotators | **no** |

## The three usual positions, and what each costs

**1. Publish in full.** What OPP-115 and most policy-annotation corpora do, on a research-use and
fair-dealing/fair-use rationale: the text is published by its authors for public reading, the use
is non-commercial research, and the annotations are worthless without the text they point at.
Simplest for reuse, and the precedent is strong. It is still redistribution without a licence.

**2. Ship offsets, not text.** Publish the annotations with character offsets and the source URLs,
and a fetch script that reconstructs the text. Removes the redistribution question entirely. It
also makes the dataset **progressively unusable** — policies change, and by the time anyone tries,
some fraction no longer matches the offsets. Several older privacy corpora died this way.

**3. Publish quotes only.** Ship the 55,350 evidence spans, not the full segment text. Short
excerpts, clearly quoted for analysis — the most defensible position. It preserves everything
needed to verify a claim, and loses the ability to measure recall, because you can no longer see
what the annotator *didn't* annotate.

## Recommendation

**Option 1, with the usual scaffolding**: a non-commercial research licence on the *annotations*
(CC BY-NC 4.0 or similar), an explicit statement that the underlying policy text remains the
property of its respective authors and is reproduced for research, and a documented takedown
contact. That is what comparable corpora do and it matches what this dataset is for.

Whatever is chosen, say it explicitly in the README. A release that is silent about the status of
its text leaves the question to whoever hosts it.

## One more thing to settle

The collection dates span 2026-02 to 2026-09. A policy fetched in February is not the policy live
today, and `corpus.json` records the URL but not the fetch date per policy. If the release is meant
to be citable, add the fetch date — it is the difference between "Dexcom's policy says X" and
"Dexcom's policy said X on this date".
